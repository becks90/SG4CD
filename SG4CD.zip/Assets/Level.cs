using System;

[Serializable]
public class Level
{
    public int level;
    public int points;
    public string reward;
}